package fr.treeptik.service.impl;

import java.util.ArrayList;
import java.util.List;

import fr.treeptik.dao.exception.DAOException;
import fr.treeptik.dao.impl.DAOFactoryJPQL;
import fr.treeptik.dao.impl.JPAutils;
import fr.treeptik.dao.interf.NumeroDAO;
import fr.treeptik.dao.interf.PersonneDAO;
import fr.treeptik.dao.pojo.Numero;
import fr.treeptik.dao.pojo.Personne;
import fr.treeptik.service.exception.ServiceException;
import fr.treeptik.service.interf.NumeroService;

public class NumeroServiceImpl implements NumeroService{
	
	private NumeroDAO numeroDAO = DAOFactoryJPQL.getNumeroDAO();
	private PersonneDAO personneDAO = DAOFactoryJPQL.getPersonneDAO();

	@Override
	public Numero add(Numero entity) throws ServiceException {
		try {
			JPAutils.begin();
			List<Personne> lp = entity.getPersonnes();
			List<Numero> ln = new ArrayList<>();
			if (!lp.isEmpty()) {
				for (Personne personne : lp) {
					personne.setNumero(ln);
					personne = personneDAO.add(personne);
				}
			}
			Numero num = numeroDAO.add(entity);
			JPAutils.commit();
			return num;
			
		} catch (DAOException e) {
			JPAutils.rollback();
			throw new ServiceException(
					"Erreur NumeroService add(Numero)"+e.getMessage(), e);
		}
	}

	@Override
	public void remove(Numero entity) throws ServiceException {
		try {
			JPAutils.begin();
			numeroDAO.remove(entity);
			JPAutils.commit();
			
		} catch (DAOException e) {
			JPAutils.rollback();
			throw new ServiceException(
					"Erreur NumeroService remove(Numero)"+e.getMessage(), e);
		}
		
	}

	@Override
	public Numero update(Numero entity) throws ServiceException {
		try {
			JPAutils.begin();
			Numero num = numeroDAO.update(entity);
			JPAutils.commit();
			return num;
			
		} catch (DAOException e) {
			JPAutils.rollback();
			throw new ServiceException(
					"Erreur NumeroService update(Numero)"+e.getMessage(), e);
		}
		
	}

	@Override
	public List<Numero> findAll() throws ServiceException {
		try {
			return numeroDAO.findAllAlt();
		} catch (DAOException e) {
			throw new ServiceException(
					"Erreur NumeroService findAll()"+e.getMessage(), e);
		}
	}

	@Override
	public Numero findByTel(String tel) throws ServiceException {
		try {
			return numeroDAO.findByTel(tel);
		} catch (DAOException e) {
			throw new ServiceException(
					"Erreur NumeroService findByTel(String)"+e.getMessage(), e);
		}
	}

	@Override
	public List<Numero> findByType(String type) throws ServiceException {
		try {
			return numeroDAO.findByType(type);
		} catch (DAOException e) {
			throw new ServiceException(
					"Erreur NumeroService findByType(String)"+e.getMessage(), e);
		}
	}

	@Override
	public Numero findById(Integer key) throws ServiceException {
		try {
			return numeroDAO.findById(key);
		} catch (DAOException e) {
			throw new ServiceException(
					"Erreur NumeroService findById(Integer)"+e.getMessage(), e);
		}
	}

}
