package fr.treeptik.dao.pojo;

public interface GenericPojo {

}
