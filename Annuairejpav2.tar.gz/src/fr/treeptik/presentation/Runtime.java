package fr.treeptik.presentation;

import fr.treeptik.dao.impl.JPAutils;

public class Runtime {

	public static void main(String[] args) {
		JPAutils.getEn();
		
		//TODO ADD NUMERO PROBLEME INVISIBLE DANS HIBERNATE
		
		Boolean loop = true;
		MenuPresentation menu = new MenuPresentation();
		System.out.println("////////BIENVENUE DANS VOTRE ANNAIRE///////////");
		while(loop){
			loop = menu.menuPrincipal();
			
		}
		
		System.out.println("See ya Amigo :)");
	}

}
